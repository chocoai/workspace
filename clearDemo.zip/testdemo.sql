/*
Navicat MySQL Data Transfer

Source Server         : 本机
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : testdemo

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2018-03-19 16:06:09
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `authority`
-- ----------------------------
DROP TABLE IF EXISTS `authority`;
CREATE TABLE `authority` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `buttons` varchar(50) DEFAULT NULL,
  `checked` int(11) DEFAULT NULL,
  `expanded` int(11) NOT NULL DEFAULT '0',
  `icon_cls` varchar(20) DEFAULT NULL,
  `leaf` int(11) NOT NULL DEFAULT '0',
  `menu_code` varchar(50) NOT NULL,
  `menu_config` varchar(200) DEFAULT NULL,
  `menu_name` varchar(50) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `sort_order` int(11) NOT NULL,
  `url` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of authority
-- ----------------------------
INSERT INTO `authority` VALUES ('1', '', null, '1', ' ', '0', 'BaseData', ' ', '基础数据', null, '100', '');
INSERT INTO `authority` VALUES ('15', '', null, '1', '', '0', 'SystemManage', '', '系统管理', null, '400', '');
INSERT INTO `authority` VALUES ('16', 'Add,Edit,Delete,View', null, '1', ' ', '1', 'UserManagement', ' ', '用户管理', '15', '4001', 'systemManage.UserManagement');
INSERT INTO `authority` VALUES ('17', ' ', null, '1', ' ', '1', 'AuthorizationManagement', ' ', '权限管理', '15', '4002', 'systemManage.AuthorizationManagement');
INSERT INTO `authority` VALUES ('18', 'Add,Edit,Delete,View', null, '1', ' ', '1', 'TestDemo', ' ', '示例样本', '15', '4003', 'systemManage.TestDemoManagement');
INSERT INTO `authority` VALUES ('19', 'Add,Edit,Delete,View', null, '1', ' ', '1', 'ResourceManagement', ' ', '资源管理', '15', '4004', 'systemManage.ResourceManagement');
INSERT INTO `authority` VALUES ('20', 'Add,Edit,Delete,View', null, '1', ' ', '1', 'DepartmentManagement', ' ', '部门管理', '15', '4005', '');
INSERT INTO `authority` VALUES ('21', '', null, '1', ' ', '0', 'Report', ' ', '报表', null, '500', ' ');
INSERT INTO `authority` VALUES ('22', ' ', null, '1', ' ', '1', 'MonthReport', ' ', '月报表', '21', '5001', '');
INSERT INTO `authority` VALUES ('23', ' ', null, '1', ' ', '1', 'QuarterReport', ' ', '季度报表', '21', '5002', '');
INSERT INTO `authority` VALUES ('24', ' ', null, '1', ' ', '1', 'YearReport', ' ', '年度报表', '21', '5003', '');
INSERT INTO `authority` VALUES ('25', 'Add,Edit,Delete,View,', null, '1', '', '1', 'oldManInfo', '', '老人基础数据', '1', '1001', 'baseData.OldManManagement');
INSERT INTO `authority` VALUES ('26', 'Add,Edit,Delete,View,', null, '1', '', '1', 'orderInfo', '', '订单数据', '1', '1002', '');
INSERT INTO `authority` VALUES ('27', 'Add,Edit,Delete,View,', null, '1', '', '1', 'callInfo', '', '呼叫记录', '1', '1003', '');

-- ----------------------------
-- Table structure for `role_authority`
-- ----------------------------
DROP TABLE IF EXISTS `role_authority`;
CREATE TABLE `role_authority` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `authority_id` varchar(10) NOT NULL,
  `role` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=988 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role_authority
-- ----------------------------
INSERT INTO `role_authority` VALUES ('159', '15', '3');
INSERT INTO `role_authority` VALUES ('160', '16', '3');
INSERT INTO `role_authority` VALUES ('161', '17', '3');
INSERT INTO `role_authority` VALUES ('164', '19', '3');
INSERT INTO `role_authority` VALUES ('165', '19Add', '3');
INSERT INTO `role_authority` VALUES ('166', '20', '3');
INSERT INTO `role_authority` VALUES ('167', '21', '3');
INSERT INTO `role_authority` VALUES ('168', '23', '3');
INSERT INTO `role_authority` VALUES ('954', '1', '1');
INSERT INTO `role_authority` VALUES ('955', '25', '1');
INSERT INTO `role_authority` VALUES ('956', '25Add', '1');
INSERT INTO `role_authority` VALUES ('957', '25Edit', '1');
INSERT INTO `role_authority` VALUES ('958', '25Delete', '1');
INSERT INTO `role_authority` VALUES ('959', '25View', '1');
INSERT INTO `role_authority` VALUES ('960', '26', '1');
INSERT INTO `role_authority` VALUES ('961', '27', '1');
INSERT INTO `role_authority` VALUES ('962', '15', '1');
INSERT INTO `role_authority` VALUES ('963', '16', '1');
INSERT INTO `role_authority` VALUES ('964', '16Add', '1');
INSERT INTO `role_authority` VALUES ('965', '16Edit', '1');
INSERT INTO `role_authority` VALUES ('966', '16Delete', '1');
INSERT INTO `role_authority` VALUES ('967', '16View', '1');
INSERT INTO `role_authority` VALUES ('968', '17', '1');
INSERT INTO `role_authority` VALUES ('969', '18', '1');
INSERT INTO `role_authority` VALUES ('970', '18Add', '1');
INSERT INTO `role_authority` VALUES ('971', '18Edit', '1');
INSERT INTO `role_authority` VALUES ('972', '18Delete', '1');
INSERT INTO `role_authority` VALUES ('973', '18View', '1');
INSERT INTO `role_authority` VALUES ('974', '19', '1');
INSERT INTO `role_authority` VALUES ('975', '19Add', '1');
INSERT INTO `role_authority` VALUES ('976', '19Edit', '1');
INSERT INTO `role_authority` VALUES ('977', '19Delete', '1');
INSERT INTO `role_authority` VALUES ('978', '19View', '1');
INSERT INTO `role_authority` VALUES ('979', '20', '1');
INSERT INTO `role_authority` VALUES ('980', '20Add', '1');
INSERT INTO `role_authority` VALUES ('981', '20Edit', '1');
INSERT INTO `role_authority` VALUES ('982', '20Delete', '1');
INSERT INTO `role_authority` VALUES ('983', '20View', '1');
INSERT INTO `role_authority` VALUES ('984', '21', '1');
INSERT INTO `role_authority` VALUES ('985', '22', '1');
INSERT INTO `role_authority` VALUES ('986', '23', '1');
INSERT INTO `role_authority` VALUES ('987', '24', '1');

-- ----------------------------
-- Table structure for `sys_user`
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) DEFAULT NULL,
  `last_logintime` datetime DEFAULT NULL,
  `password` varchar(32) NOT NULL,
  `real_name` varchar(30) DEFAULT NULL,
  `role` smallint(6) NOT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `user_name` varbinary(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_cb0fsvip6qow952a07et2k9xv` (`user_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', '1298588579@qq.com', '2018-03-19 16:00:44', 'e10adc3949ba59abbe56e057f20f883e', '冯坤', '1', '', 0x61646D696E);
INSERT INTO `sys_user` VALUES ('2', '', '2014-08-04 15:35:01', 'e10adc3949ba59abbe56e057f20f883e', '', '3', '', 0x74657374);
INSERT INTO `sys_user` VALUES ('3', '231788364@qq.com', '2018-03-06 15:04:29', 'e10adc3949ba59abbe56e057f20f883e', '测试用户1', '2', '18627899131', 0x7465737431);

-- ----------------------------
-- Table structure for `test_demo`
-- ----------------------------
DROP TABLE IF EXISTS `test_demo`;
CREATE TABLE `test_demo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `tel` varchar(16) DEFAULT NULL,
  `type` int(2) DEFAULT NULL,
  `area` varchar(32) DEFAULT NULL,
  `createtime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of test_demo
-- ----------------------------
INSERT INTO `test_demo` VALUES ('1', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('3', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('5', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('6', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('7', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('8', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('9', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('10', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('11', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('12', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('13', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('14', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('15', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('16', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('17', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('18', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('19', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('20', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('21', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('22', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('23', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('24', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('25', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('26', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('27', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('28', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('29', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('30', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('31', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('32', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('33', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('34', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('35', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('36', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('37', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('38', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('39', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('40', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('41', '测试', '18627899133', '1', '湖北', '2018-03-09 09:34:22');
INSERT INTO `test_demo` VALUES ('42', '阿三', '18726732212', '2', '湖南', '2018-03-10 14:13:04');
INSERT INTO `test_demo` VALUES ('43', '冯坤', '18627899132', '2', '湖北', '2018-03-16 11:28:07');
