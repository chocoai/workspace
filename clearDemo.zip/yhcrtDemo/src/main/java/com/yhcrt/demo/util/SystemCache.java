package com.yhcrt.demo.util;

import java.util.HashMap;

import java.util.Map;

/**
 * @author fengkun
 * @email 231788364@qq.com
 */
public class SystemCache {

	private SystemCache() {

	}

	public static final Map<String, Group> DICTIONARY = new HashMap<String, Group>();

}
